﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Model;

namespace WebapiCore.Extensions
{
    public static class ModelBuilderExtensions
    {
        public static void SeedCountry(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Country>().HasData(
                new Country
                {
                    CountryId=1,
                    Title = "India",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                }
            );
        }

        public static void SeedAddressType(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AddressType>().HasData(
                new AddressType
                {
                    AddressTypeId = Guid.NewGuid(),
                    Title = "Present",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                },
                 new AddressType
                 {
                     AddressTypeId = Guid.NewGuid(),
                     Title = "Permanenet",
                     IsActive = true,
                     CreatedOn = DateTime.Now,
                 }
            );
        }
        public static void SeedState(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<State>().HasData(
                new State
                {
                    CountryId = 1,
                    StateId=1,
                    Title = "Maharashtra",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                },
                new State
                {
                    CountryId = 1,
                    StateId = 2,
                    Title = "UttarPradesh",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                },
                new State
                {
                    CountryId = 1,
                    StateId = 3,
                    Title = "MadhyaPradesh",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                }
            );
        }

        public static void SeedCity(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<City>().HasData(
                new City
                {
                    CityId = 1,
                    StateId = 1,
                    Title = "Mumbai",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                },
                new City
                {
                    CityId = 2,
                    StateId = 2,
                    Title = "Lucknow",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                },
                new City
                {
                    CityId = 3,
                    StateId = 3,
                    Title = "Indore",
                    IsActive = true,
                    CreatedOn = DateTime.Now,
                }
            );
        }
    }
    
}
