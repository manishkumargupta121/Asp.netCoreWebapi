﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebapiCore.Contracts
{
    public static class ApiRoutes
    {
        public const string Root = "api";
        public const string Base = Root + "/" ;
        public static class Countries
        {
            public const string GetAll = Base + "/countries";
        }

        public static class Cities
        {
            public const string GetAll = Base + "/cities";
        }

        public static class States
        {
            public const string GetAll = Base + "/states";
        }
    }
}
