﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Model;
using WebapiCore.Request;

namespace WebapiCore.Validator
{
    public class EmployeeJobInformationValidator : AbstractValidator<CreateEmployeeJobInformationRequest>
    {
        public EmployeeJobInformationValidator()
        {
            RuleFor(x => x.EmailId).NotNull().EmailAddress().WithMessage("Invalid Email Address");
            RuleFor(x=>x.Title).NotNull();
            RuleFor(x => x.WorkLocation).NotNull();
            RuleFor(x => x.Salary).NotNull().Must(BeANumber)
                                            .WithMessage("Must be a number"); ;
        }
        private bool BeANumber(string value)
        {
            int result;
            if (Int32.TryParse(value, out result))
            {
                return true;
            }
            return false;
        }
    }
}
