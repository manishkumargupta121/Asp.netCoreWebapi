﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using WebapiCore.Model;
using WebapiCore.Request;

namespace WebapiCore.Validator
{
    public class EmployeePersonalInformationValidator:AbstractValidator<CreateEmployeeInformationRequest>
    {
        public EmployeePersonalInformationValidator()
        {
            RuleFor(x => x.EmailId).NotNull().EmailAddress().WithMessage("Invalid Email Address"); 
            RuleFor(x => x.FirstName).NotNull();
            RuleFor(x => x.MiddleName).NotNull();
            RuleFor(x => x.LastName).NotNull();
            RuleFor(x => x.HomePhoneNo).NotNull().MaximumLength(12).Must(BeANumber)
                                                                    .WithMessage("Must be a number"); ;

            RuleFor(x => x.AlternatePhoneNo).NotNull().MaximumLength(12);
            RuleFor(x => x.BirthDate).NotNull().Must(BeAValidDate)
                        .WithMessage("Invalid date/time"); 
        }

        private bool BeAValidDate(DateTime arg)
        {
            DateTime date;
            return DateTime.TryParse(Convert.ToString(arg), out date);
        }
        private bool BeANumber(string value)
        {
            int result;
            if (Int32.TryParse(value, out result))
            {
                return true;
            }
            return false;
        }

    }
}
