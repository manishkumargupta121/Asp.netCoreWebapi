﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using WebapiCore.Model;
using WebapiCore.Request;

namespace WebapiCore.Validator
{
    public class EmployeeAddressValidator : AbstractValidator<CreateEmployeeAddressRequest>
    {
        public EmployeeAddressValidator()
        {
            RuleFor(x => x.AddressTypeId).NotNull();

            RuleFor(x => x.CityId).NotNull();
            RuleFor(x => x.StateId).NotNull();
            RuleFor(x => x.CountryId).NotNull();
            RuleFor(x => x.Address1).NotNull();
            RuleFor(x => x.Address2).NotNull();
        
        }
    }
}
