﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Model;
using WebapiCore.Request;

namespace WebapiCore.AutoMapping
{
    public class AutoMapping:Profile
    {
        public AutoMapping()
        {
            CreateMap<CreateEmployeeInformationRequest,EmployeePersonalInformation>();
            CreateMap<CreateEmployeeJobInformationRequest,EmployeeJobInformation>();
            CreateMap<CreateEmployeeAddressRequest,EmployeeAddress>();
        }
    }
}
