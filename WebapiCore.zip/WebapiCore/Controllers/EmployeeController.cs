﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebapiCore.Model;
using WebapiCore.Request;
using WebapiCore.Services;

namespace WebapiCore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _personalInformationService;
        private readonly IMapper _mapper;
        public EmployeeController(IEmployeeService personalInformationService,IMapper mapper)
        {
            _personalInformationService = personalInformationService;
            _mapper = mapper;
        }
        [HttpPost("Create")]
        public async Task<IActionResult> Create([FromBody] CreateEmployeeInformationRequest postRequest)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                return Ok(new
                {
                    isSuccess = false,
                    Message = "Error occured",
                    ErroMessage = errors,
                });
            }

            //EmployeePersonalInformation employeePersonalInformation = new EmployeePersonalInformation();
            List<EmployeeAddress> employeeAddresses = new List<EmployeeAddress>();
            List<EmployeeJobInformation> employeeJobInformation = new List<EmployeeJobInformation>();
            var newEmployeeId = Guid.NewGuid();
            //employeePersonalInformation = new EmployeePersonalInformation
            //{
            //    EmployeeId = newEmployeeId,
            //    FirstName = postRequest.FirstName,
            //    MiddleName=postRequest.MiddleName,
            //    LastName=postRequest.LastName,
            //    HomePhoneNo=postRequest.HomePhoneNo,
            //    AlternatePhoneNo=postRequest.AlternatePhoneNo,
            //    EmailId=postRequest.EmailId,
            //    BirthDate=postRequest.BirthDate,
            //    Gender=postRequest.Gender,
            //    IsActive=postRequest.IsActive,
            //    CreatedOn=DateTime.Now,
            //};
            var employeePersonal = _mapper.Map<EmployeePersonalInformation>(postRequest);
            employeePersonal.EmployeeId = newEmployeeId;
            employeePersonal.CreatedOn = DateTime.Now;

            foreach (var item in postRequest.EmployeeAddress)
            {
              //var employeeAddress=  new EmployeeAddress
              //  {
              //      AddressId = Guid.NewGuid(),
              //      AddressTypeId = item.AddressTypeId,
              //      EmployeeId = newEmployeeId,
              //      Address1 = item.Address1,
              //      Address2 = item.Address2,
              //      CityId = item.CityId,
              //      StateId = item.StateId,
              //      CountryId = item.CountryId,
              //      IsActive = item.IsActive,
              //      CreatedOn = DateTime.Now
              //  };
                var address = _mapper.Map<EmployeeAddress>(item);
                address.AddressId = Guid.NewGuid();
                address.EmployeeId = newEmployeeId;
                address.CreatedOn = DateTime.Now;
                employeeAddresses.Add(address);

            }

            foreach (var item in postRequest.EmployeeJobInformations)
            {
                //var employeeJob = new EmployeeJobInformation
                //{

                //    JobInformationId = Guid.NewGuid(),
                //    EmployeeId = newEmployeeId,
                //    Title= item.Title,
                //    WorkLocation= item.WorkLocation,
                //    EmailId= item.EmailId,
                //    Salary= item.Salary,
                //    IsActive= item.IsActive,
                //    CreatedOn=DateTime.Now
                //};

                var job = _mapper.Map<EmployeeJobInformation>(item);
                job.JobInformationId = Guid.NewGuid();
                job.EmployeeId = newEmployeeId;
                job.CreatedOn = DateTime.Now;
                employeeJobInformation.Add(job);
            }
            employeePersonal.EmployeeAddress = employeeAddresses;
            employeePersonal.EmployeeJobInformations = employeeJobInformation;
            //employeePersonalInformation.EmployeeAddress = employeeAddresses;
            //employeePersonalInformation.EmployeeJobInformations = employeeJobInformation;
            await _personalInformationService.CreatePersonalInformationAsync(employeePersonal);
            return Ok(new
            {
                isSuccess = true,
                
                Message = "Data Loaded Successfully",
                ErroMessage = "",
            });

        }

        [HttpPut("Update")]
        public async Task<IActionResult> Update([FromRoute] Guid employeeId, [FromBody] EmployeePersonalInformation postRequest)
        {
            EmployeePersonalInformation employeePersonalInformation = new EmployeePersonalInformation();
            List<EmployeeAddress> employeeAddresses = new List<EmployeeAddress>();
            List<EmployeeJobInformation> employeeJobInformation = new List<EmployeeJobInformation>();
            var newEmployeeId = employeeId;
            employeePersonalInformation = new EmployeePersonalInformation
            {
                EmployeeId = newEmployeeId,
                FirstName = postRequest.FirstName,
                MiddleName = postRequest.MiddleName,
                LastName = postRequest.LastName,
                HomePhoneNo = postRequest.HomePhoneNo,
                AlternatePhoneNo = postRequest.AlternatePhoneNo,
                EmailId = postRequest.EmailId,
                BirthDate = postRequest.BirthDate,
                Gender = postRequest.Gender,
                IsActive = postRequest.IsActive,
                CreatedOn = DateTime.Now,
            };

            foreach (var item in postRequest.EmployeeAddress)
            {
                var employeeAddress = new EmployeeAddress
                {
                    AddressId = item.AddressId,
                    AddressTypeId = item.AddressTypeId,
                    EmployeeId = newEmployeeId,
                    Address1 = item.Address1,
                    Address2 = item.Address2,
                    CityId = item.CityId,
                    StateId = item.StateId,
                    CountryId = item.CountryId,
                    IsActive = item.IsActive,
                    CreatedOn = DateTime.Now
                };
                employeeAddresses.Add(employeeAddress);
            }

            foreach (var item in postRequest.EmployeeJobInformations)
            {
                var employeeJob = new EmployeeJobInformation
                {

                    JobInformationId = item.JobInformationId,
                    EmployeeId = newEmployeeId,
                    Title = item.Title,
                    WorkLocation = item.WorkLocation,
                    EmailId = item.EmailId,
                    Salary = item.Salary,
                    IsActive = item.IsActive,
                    CreatedOn = DateTime.Now
                };
                employeeJobInformation.Add(employeeJob);
            }
            employeePersonalInformation.EmployeeAddress = employeeAddresses;
            employeePersonalInformation.EmployeeJobInformations = employeeJobInformation;
            await _personalInformationService.UpdatePersonalInformationAsync(employeePersonalInformation);
            return Ok(new
            {
                isSuccess = true,
                Message = "Data Updated Successfully",
                ErroMessage = "",
            });

        }
      
        
        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(string employeeId)
        {
          
            var dataRecord = await _personalInformationService.GetPersonalInformationByIdAsync(employeeId);
            if (dataRecord == null)
                return NoContent();
            var deleted = await _personalInformationService.DeletePersonalInformationAsync(employeeId);
            return Ok(new
            {
                isSuccess = deleted,
                Message = "Data Deleted Successfully",
                ErroMessage = "",
            });
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var dataRecord = await _personalInformationService.GetAllPersonalInformationAsync();
            return Ok(new
            {
                isSuccess = true,
                Message = "Data Fetched Successfully",
                ErroMessage = "",
                dataRecord
            });
        }

        [HttpGet("Get")]
        public async Task<IActionResult> Get(string employeeId)
        {
            var dataRecord = await _personalInformationService.GetPersonalInformationByIdAsync(employeeId);
            if (dataRecord == null)
                return NoContent();

            return Ok(new
            {
                isSuccess = true,
                Message = "Data Fetched Successfully",
                ErroMessage = "",
                dataRecord
            });
        }
    }
}
