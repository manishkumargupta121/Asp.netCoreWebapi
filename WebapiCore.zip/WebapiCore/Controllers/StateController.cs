﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebapiCore.Contracts;
using WebapiCore.Services;

namespace WebapiCore.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class StateController : ControllerBase
    {
        private readonly IStateService _stateService;
        public StateController(IStateService stateService)
        {
            _stateService = stateService;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var states = await _stateService.GetAllStateAsync();
            return Ok(new
            {
                isSuccess = true,
                Message = "Success",
                ErroMessage = "",
                states
            });
        }
    }
}
