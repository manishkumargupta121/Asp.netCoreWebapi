﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace WebapiCore.Model
{
    public class State
    {
        [Key]
        public int StateId { get; set; }
        public string Title { get; set; }
        public int CountryId { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

        [ForeignKey(nameof(CountryId))]
        public Country Country { get; set; }
    }
}
