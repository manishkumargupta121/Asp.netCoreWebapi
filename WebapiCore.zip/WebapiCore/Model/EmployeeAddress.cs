﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace WebapiCore.Model
{
    public class EmployeeAddress
    {
        [Key]
        public Guid AddressId { get; set; }
        public Guid AddressTypeId { get; set; }
        public Guid EmployeeId { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public int CityId { get; set; }
        public int StateId { get; set; }
        public int CountryId { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

       [ForeignKey(nameof(AddressTypeId))]
        public AddressType AddressType { get; set; }

        [ForeignKey(nameof(EmployeeId))]
        public EmployeePersonalInformation EmployeePersonalInformation { get; set; }

     
    }
}
