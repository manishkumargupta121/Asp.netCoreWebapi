﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebapiCore.Model
{
    public class AddressType
    {
        [Key]
        public Guid AddressTypeId { get; set; }

        public string Title { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
