﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebapiCore.Model
{
    public class City
    {
        [Key]
        public int CityId { get; set; }
        public string Title { get; set; }
        public int StateId { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

        [ForeignKey(nameof(StateId))]
        public State State { get; set; }


    }
}
