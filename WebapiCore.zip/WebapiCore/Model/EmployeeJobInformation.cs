﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebapiCore.Model
{
    public class EmployeeJobInformation
    {
        [Key]
        public Guid JobInformationId { get; set; }

        public Guid EmployeeId { get; set; }

        public string Title { get; set; }

        public string WorkLocation { get; set; }

        public string EmailId { get; set; }

        public string Salary { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

        [ForeignKey(nameof(EmployeeId))]
        public EmployeePersonalInformation EmployeePersonalInformation { get; set; }
    }
}
