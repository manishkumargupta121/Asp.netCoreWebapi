﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebapiCore.Migrations
{
    public partial class adding_id_employees_details : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("abb5149d-60c9-4d28-a2f4-72ca7ec715a4"));

            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("bbd3b1b0-e2ad-44ab-800c-c839f5387f23"));

            migrationBuilder.InsertData(
                table: "AddressTypes",
                columns: new[] { "AddressTypeId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { new Guid("71d9806d-eea9-4f52-864d-1ba378a17fc8"), new DateTime(2020, 7, 17, 22, 0, 29, 172, DateTimeKind.Local).AddTicks(4318), true, "Present" },
                    { new Guid("3d17562d-3181-43dc-8667-d2535dcd7033"), new DateTime(2020, 7, 17, 22, 0, 29, 172, DateTimeKind.Local).AddTicks(6033), true, "Permanenet" }
                });

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 170, DateTimeKind.Local).AddTicks(3595));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 170, DateTimeKind.Local).AddTicks(4612));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 170, DateTimeKind.Local).AddTicks(4644));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 162, DateTimeKind.Local).AddTicks(9672));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 169, DateTimeKind.Local).AddTicks(343));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 169, DateTimeKind.Local).AddTicks(1759));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 22, 0, 29, 169, DateTimeKind.Local).AddTicks(1784));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("3d17562d-3181-43dc-8667-d2535dcd7033"));

            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("71d9806d-eea9-4f52-864d-1ba378a17fc8"));

            migrationBuilder.InsertData(
                table: "AddressTypes",
                columns: new[] { "AddressTypeId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { new Guid("abb5149d-60c9-4d28-a2f4-72ca7ec715a4"), new DateTime(2020, 7, 17, 16, 31, 10, 877, DateTimeKind.Local).AddTicks(5539), true, "Present" },
                    { new Guid("bbd3b1b0-e2ad-44ab-800c-c839f5387f23"), new DateTime(2020, 7, 17, 16, 31, 10, 877, DateTimeKind.Local).AddTicks(6380), true, "Permanenet" }
                });

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(7726));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(8958));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(8970));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 871, DateTimeKind.Local).AddTicks(8987));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 875, DateTimeKind.Local).AddTicks(9722));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(440));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(452));
        }
    }
}
