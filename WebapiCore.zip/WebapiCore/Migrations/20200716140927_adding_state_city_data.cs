﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebapiCore.Migrations
{
    public partial class adding_state_city_data : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 203, DateTimeKind.Local).AddTicks(1368));

            migrationBuilder.InsertData(
                table: "States",
                columns: new[] { "StateId", "CountryId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(1221), true, "Maharashtra" },
                    { 2, 1, new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(7035), true, "UttarPradesh" },
                    { 3, 1, new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(7083), true, "MadhyaPradesh" }
                });

            migrationBuilder.InsertData(
                table: "Cities",
                columns: new[] { "CityId", "CreatedOn", "IsActive", "StateId", "Title" },
                values: new object[] { 1, new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(5721), true, 1, "Mumbai" });

            migrationBuilder.InsertData(
                table: "Cities",
                columns: new[] { "CityId", "CreatedOn", "IsActive", "StateId", "Title" },
                values: new object[] { 2, new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(6812), true, 2, "Lucknow" });

            migrationBuilder.InsertData(
                table: "Cities",
                columns: new[] { "CityId", "CreatedOn", "IsActive", "StateId", "Title" },
                values: new object[] { 3, new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(6851), true, 3, "Indore" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3);

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 21, 47, 810, DateTimeKind.Local).AddTicks(8795));
        }
    }
}
