﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebapiCore.Migrations
{
    public partial class adding_address_type_Data : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AddressTypes",
                columns: new[] { "AddressTypeId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { new Guid("44771505-f9ad-4f9a-9e30-c01cff307204"), new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(7564), true, "Present" },
                    { new Guid("fec86102-9434-45f3-8449-832c9a5a3418"), new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(8443), true, "Permanenet" }
                });

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 636, DateTimeKind.Local).AddTicks(9263));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(75));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(98));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 630, DateTimeKind.Local).AddTicks(2469));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(3467));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(4299));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(4318));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("44771505-f9ad-4f9a-9e30-c01cff307204"));

            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("fec86102-9434-45f3-8449-832c9a5a3418"));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(8734));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(9444));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(9457));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 729, DateTimeKind.Local).AddTicks(4050));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(1018));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(2586));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(2601));
        }
    }
}
