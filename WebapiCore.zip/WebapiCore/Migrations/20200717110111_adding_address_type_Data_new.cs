﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebapiCore.Migrations
{
    public partial class adding_address_type_Data_new : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("44771505-f9ad-4f9a-9e30-c01cff307204"));

            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("fec86102-9434-45f3-8449-832c9a5a3418"));

            migrationBuilder.InsertData(
                table: "AddressTypes",
                columns: new[] { "AddressTypeId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { new Guid("abb5149d-60c9-4d28-a2f4-72ca7ec715a4"), new DateTime(2020, 7, 17, 16, 31, 10, 877, DateTimeKind.Local).AddTicks(5539), true, "Present" },
                    { new Guid("bbd3b1b0-e2ad-44ab-800c-c839f5387f23"), new DateTime(2020, 7, 17, 16, 31, 10, 877, DateTimeKind.Local).AddTicks(6380), true, "Permanenet" }
                });

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(7726));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(8958));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(8970));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 871, DateTimeKind.Local).AddTicks(8987));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 875, DateTimeKind.Local).AddTicks(9722));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(440));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 31, 10, 876, DateTimeKind.Local).AddTicks(452));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("abb5149d-60c9-4d28-a2f4-72ca7ec715a4"));

            migrationBuilder.DeleteData(
                table: "AddressTypes",
                keyColumn: "AddressTypeId",
                keyValue: new Guid("bbd3b1b0-e2ad-44ab-800c-c839f5387f23"));

            migrationBuilder.InsertData(
                table: "AddressTypes",
                columns: new[] { "AddressTypeId", "CreatedOn", "IsActive", "Title" },
                values: new object[,]
                {
                    { new Guid("44771505-f9ad-4f9a-9e30-c01cff307204"), new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(7564), true, "Present" },
                    { new Guid("fec86102-9434-45f3-8449-832c9a5a3418"), new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(8443), true, "Permanenet" }
                });

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 636, DateTimeKind.Local).AddTicks(9263));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(75));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 637, DateTimeKind.Local).AddTicks(98));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 630, DateTimeKind.Local).AddTicks(2469));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(3467));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(4299));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 28, 42, 634, DateTimeKind.Local).AddTicks(4318));
        }
    }
}
