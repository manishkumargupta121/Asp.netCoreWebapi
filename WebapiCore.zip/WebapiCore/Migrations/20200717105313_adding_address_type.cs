﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebapiCore.Migrations
{
    public partial class adding_address_type : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeAddresses_Posts_AddressTypeId",
                table: "EmployeeAddresses");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Posts",
                table: "Posts");

            migrationBuilder.RenameTable(
                name: "Posts",
                newName: "AddressTypes");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AddressTypes",
                table: "AddressTypes",
                column: "AddressTypeId");

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(8734));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(9444));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(9457));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 729, DateTimeKind.Local).AddTicks(4050));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(1018));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(2586));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 17, 16, 23, 12, 734, DateTimeKind.Local).AddTicks(2601));

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeAddresses_AddressTypes_AddressTypeId",
                table: "EmployeeAddresses",
                column: "AddressTypeId",
                principalTable: "AddressTypes",
                principalColumn: "AddressTypeId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeAddresses_AddressTypes_AddressTypeId",
                table: "EmployeeAddresses");

            migrationBuilder.DropPrimaryKey(
                name: "PK_AddressTypes",
                table: "AddressTypes");

            migrationBuilder.RenameTable(
                name: "AddressTypes",
                newName: "Posts");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Posts",
                table: "Posts",
                column: "AddressTypeId");

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(5721));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(6812));

            migrationBuilder.UpdateData(
                table: "Cities",
                keyColumn: "CityId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 211, DateTimeKind.Local).AddTicks(6851));

            migrationBuilder.UpdateData(
                table: "Countries",
                keyColumn: "CountryId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 203, DateTimeKind.Local).AddTicks(1368));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 1,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(1221));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 2,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(7035));

            migrationBuilder.UpdateData(
                table: "States",
                keyColumn: "StateId",
                keyValue: 3,
                column: "CreatedOn",
                value: new DateTime(2020, 7, 16, 19, 39, 26, 210, DateTimeKind.Local).AddTicks(7083));

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeAddresses_Posts_AddressTypeId",
                table: "EmployeeAddresses",
                column: "AddressTypeId",
                principalTable: "Posts",
                principalColumn: "AddressTypeId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
