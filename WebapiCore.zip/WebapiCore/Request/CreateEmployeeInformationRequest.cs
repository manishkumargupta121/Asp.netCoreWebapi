﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Utility;

namespace WebapiCore.Request
{
    public class CreateEmployeeInformationRequest
    {
            public string FirstName { get; set; }

            public string MiddleName { get; set; }

            public string LastName { get; set; }

            public string HomePhoneNo { get; set; }

            public string AlternatePhoneNo { get; set; }

            public string EmailId { get; set; }

            public DateTime BirthDate { get; set; }

            public Gender Gender { get; set; }

            public bool IsActive { get; set; }
            public DateTime CreatedOn { get; set; }

            public virtual List<CreateEmployeeAddressRequest> EmployeeAddress { get; set; }

            public virtual List<CreateEmployeeJobInformationRequest> EmployeeJobInformations { get; set; }
       
    }
   public  class CreateEmployeeAddressRequest
    {
            public Guid AddressTypeId { get; set; }
            public string Address1 { get; set; }
            public string Address2 { get; set; }
            public int CityId { get; set; }
            public int StateId { get; set; }
            public int CountryId { get; set; }
            public bool IsActive { get; set; }
            public DateTime CreatedOn { get; set; }
    }
   public class CreateEmployeeJobInformationRequest
    {
            public string Title { get; set; }
            public string WorkLocation { get; set; }
            public string EmailId { get; set; }
            public string Salary { get; set; }
            public bool IsActive { get; set; }
            public DateTime CreatedOn { get; set; }
    }
}
