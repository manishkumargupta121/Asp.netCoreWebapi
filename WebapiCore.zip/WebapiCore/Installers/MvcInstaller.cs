﻿using AutoMapper;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebapiCore.Model;
using WebapiCore.Options;
using WebapiCore.Request;
using WebapiCore.Validator;

namespace WebapiCore.Installers
{
    public class MvcInstaller : IInstaller
    {
        public void InstallServices(IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllers()
                .AddNewtonsoftJson(
                    options => {
                                options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                                })
                .AddFluentValidation();
            services.AddAutoMapper(typeof(Startup));
            services.AddTransient<IValidator<CreateEmployeeInformationRequest>,EmployeePersonalInformationValidator>();
            services.AddTransient<IValidator<CreateEmployeeAddressRequest>, EmployeeAddressValidator>();
            services.AddTransient<IValidator<CreateEmployeeJobInformationRequest>, EmployeeJobInformationValidator>();
        }
    }
}
