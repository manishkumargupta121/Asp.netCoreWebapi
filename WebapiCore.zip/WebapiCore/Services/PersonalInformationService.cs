﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Data;
using WebapiCore.Migrations;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public class EmployeeService : IEmployeeService
    {

        private readonly DataContext _dataContext;
        public EmployeeService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }
        public async Task<bool> CreatePersonalInformationAsync(EmployeePersonalInformation employeePersonalInformation)
        {
            await _dataContext.EmployeePersonalInformations.AddAsync(employeePersonalInformation);
            var created = await _dataContext.SaveChangesAsync();
            return created > 0;
        }

        public async Task<bool> DeletePersonalInformationAsync(string EmployeeId)
        {
            var personalInformation = await GetPersonalInformationByIdAsync(EmployeeId);

            if (personalInformation == null)
                return false;

            _dataContext.EmployeePersonalInformations.Remove(personalInformation);
            var deleted = await _dataContext.SaveChangesAsync();
            return deleted > 0;
        }

        public async Task<List<EmployeePersonalInformation>> GetAllPersonalInformationAsync()
        {
            return await _dataContext.EmployeePersonalInformations
                .Include(x => x.EmployeeJobInformations)
                .Include(x => x.EmployeeAddress)
                .ToListAsync();
               
        }

        public async Task<EmployeePersonalInformation> GetPersonalInformationByIdAsync(string EmployeeId)
        {
           Guid guid= new Guid(EmployeeId);
            return await _dataContext.EmployeePersonalInformations
                .Include(x => x.EmployeeJobInformations)
                .Include(x => x.EmployeeAddress)
                .SingleOrDefaultAsync(x => x.EmployeeId == guid);
        }

        public async Task<bool> UpdatePersonalInformationAsync(EmployeePersonalInformation employeePersonalInformation)
        {
            _dataContext.EmployeePersonalInformations.Update(employeePersonalInformation);
            var updated = await _dataContext.SaveChangesAsync();
            return updated > 0;
        }
    }
}
