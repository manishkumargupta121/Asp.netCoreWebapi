﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public interface IEmployeeService
    {
        Task<List<EmployeePersonalInformation>> GetAllPersonalInformationAsync();
        Task<bool> CreatePersonalInformationAsync(EmployeePersonalInformation employeePersonalInformation);
        Task<EmployeePersonalInformation> GetPersonalInformationByIdAsync(string EmployeeId);
        Task<bool> UpdatePersonalInformationAsync(EmployeePersonalInformation employeePersonalInformation);
        Task<bool> DeletePersonalInformationAsync(string EmployeeId);

    }
}
