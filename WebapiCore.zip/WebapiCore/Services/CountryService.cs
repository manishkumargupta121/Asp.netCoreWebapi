﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Data;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public class CountryService : ICountryService
    {
        private readonly DataContext _dataContext;
        public CountryService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }
        public async Task<List<Country>> GetAllCountryAsync()
        {
            return await _dataContext.Countries.AsNoTracking().ToListAsync();
        }
    }
}
