﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public interface IStateService
    {
        Task<List<State>> GetAllStateAsync();
    }
}
