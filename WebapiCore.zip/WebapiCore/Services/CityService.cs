﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Data;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public class CityService : ICityService
    {
        private readonly DataContext _dataContext;
        public CityService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }
        public async Task<List<City>> GetAllCityAsync()
        {
            return await _dataContext.Cities.AsNoTracking().ToListAsync();
        }
    }
}
