﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebapiCore.Data;
using WebapiCore.Model;

namespace WebapiCore.Services
{
    public class StateService : IStateService
    {
        private readonly DataContext _dataContext;
        public StateService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }
        public async Task<List<State>> GetAllStateAsync()
        {
            return await _dataContext.States.AsNoTracking().ToListAsync();
        }
    }
}
